<?php

ini_set('error_reporting', E_ALL ^ E_NOTICE);
define(RUTA, __DIR__ . DIRECTORY_SEPARATOR);

$hotelName = $_POST['hotel']; /*"AMARUGUA";*/
$date = $_POST['date']; /*"2017-03-20";*/
$reserve = (int)$_POST['plazas']; /*20;*/

$str= true;   
$doc = new DOMDocument();
$doc->load(RUTA . '../xml/ofertasHoyCambios.xml');
$xpath = new DOMXPath($doc);
if($result = $xpath->query("//oferta[@nombre='$hotelName']/fecha[@dia='$date']/plazas")){
    if ($reserve > (int) $result->item(0)->nodeValue) {
        $str = false;
    } else {  
        $result->item(0)->nodeValue = (int) $result->item(0)->nodeValue - $reserve;
        $doc->save(RUTA . '../xml/ofertasHoyCambios.xml');
    }
}
echo json_encode(array("reserva"=>$str));


