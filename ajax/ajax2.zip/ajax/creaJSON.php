<?php

ini_set('error_reporting', E_ALL ^ E_NOTICE);
define(RUTA, __DIR__ . DIRECTORY_SEPARATOR);

$ahora = new DateTime();
$nomFic = RUTA . "datas/" . $ahora->format('Ymdhis') . ".json";
file_put_contents($nomFic, $_POST['aCiudades']);

$aCiudades = json_decode($_POST['aCiudades'], true);
$doc = new DOMDocument();
$doc->load(RUTA . '../xml/CIUDADEStemp.xml');

foreach ($aCiudades as $k => $v) {
    $str .= "//LUGAR[@ID='$k']    -    ";
    $xpath = new DOMXPath($doc);
    foreach ($xpath->query("//LUGAR[@ID='$k']") as $ciudad) {
        $ciudad->parentNode->removeChild($ciudad);
    }
}
$doc->save(RUTA . '../xml/CIUDADEStemp.xml');

echo json_encode(array("html" => $str));
