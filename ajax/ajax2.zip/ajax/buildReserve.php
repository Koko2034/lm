<?php

ini_set('error_reporting', E_ALL ^ E_NOTICE);
define(RUTA, __DIR__ . DIRECTORY_SEPARATOR);

$id = filter_input(INPUT_POST, $_POST['id']);
$contador = filter_input(INPUT_POST, $_POST['contador']);

$aDateHotel = array(
    "nombre" => filter_input(INPUT_POST, $_POST['nombre']),
    "fecha" => filter_input(INPUT_POST, $_POST['date']),
    "plaza" => filter_input(INPUT_POST, $_POST['plazas']),
    "precio" => filter_input(INPUT_POST, $_POST['precio'])
);

checkXML($id, $contador, $aDateHotel);

function checkXML($id, $contador, $aDateHotel) {
    $buildReserve = new DOMDocument();
    if (!file_exists(RUTA . 'contentReserve.xml')) {
        $xmlHeader = '<?xml version="1.0" standalone="yes"?><Bookings>
    <InfoAgency>
    <name>OFMA107</name>
    <address><![CDATA[Málaga, 2006, c/del Politécnico]]></address>
    </InfoAgency>
    </Bookings>';
        $buildReserve->loadXML($xmlHeader);
        createXML($buildReserve, $id, $contador, $aDateHotel);
    } else {
            $buildReserve->load(RUTA . 'contentReserve.xml');
        createXML($buildReserve, $id, $contador, $aDateHotel);
    }
}

function createXML($buildReserve, $id, $contador, $aDateHotel) {

    $root = $buildReserve->childNodes/* getElementsByTagName('Bookings') */->item(0);
    $root_ele = $buildReserve->createElement('booking');
    $root_attri = $buildReserve->createAttribute('id');
    $root_attri->value = $contador;
    $root_ele->appendChild($root_attri);
    $root_ele = $root->appendChild($root_ele);

    $ele_hotel = $buildReserve->createElement('hotel');
    $attri_hotel = $buildReserve->createAttribute('id');
    $attri_hotel->value = $id;
    $ele_hotel->appendChild($attri_hotel);
    $ele_hotel = $root_ele->appendChild($ele_hotel);

    foreach ($aDateHotel as $i => $valor) {
        $date_hotel = $buildReserve->createElement($i, $valor);
        $ele_hotel->appendChild($date_hotel);
    }

    $ele_hote_ob = $ele_hotel->appendChild($buildReserve->createElement('Observaciones'));
    $ele_hote_ob->appendChild($buildReserve->createCDATASection(rand(1, 5) . ' estrellas'));

    $buildReserve->save(RUTA . 'contentReserve.xml');
}
