<?php

ini_set('error_reporting', E_ALL ^ E_NOTICE);
define(RUTA, __DIR__ . DIRECTORY_SEPARATOR);

$doc = new DOMDocument();
$doc->load(RUTA . '../xml/ofertasHoyCambios.xml');
$xpath = new DOMXPath($doc);
$hoteles = [];
$i = 0;
$fechaMax = 0;
$fechaMin = 0;
foreach ($xpath->query("//oferta") as $oferta) {
    $hoteles[$i]["id"] = $oferta->getAttribute("id");
    $hoteles[$i]["nombre"] = $oferta->getAttribute("nombre");
    foreach ($oferta->childNodes as $item) {
        if ($item->nodeType == XML_ELEMENT_NODE) {
            $hoteles[$i]["ofertas"][$item->getAttribute("dia")] = array(
                "fecha" => $item->getAttribute("dia"),
                $item->childNodes[1]->nodeName => $item->childNodes[1]->nodeValue,
                $item->childNodes[3]->nodeName => $item->childNodes[3]->nodeValue);
            if ($i == 0) {
                $fechaMax = $item->getAttribute("dia");
                $fechaMin = $item->getAttribute("dia");
            } else {
                $fechaMax = buscaFechaMayor($fechaMax, $item->getAttribute("dia"));
                $fechaMin = buscaFechaMenor($fechaMin, $item->getAttribute("dia"));
            }
        }
    }
    $i++;
}

echo json_encode(array("hoteles" => $hoteles, "fechaMax" => $fechaMax, "fechaMin" => $fechaMin));

function buscaFechaMayor($fecha1, $fecha2) {
    if ((strtotime($fecha1)) > (strtotime($fecha2))) {
        return $fecha1;
    } else {
        return $fecha2;
    }
}

function buscaFechaMenor($fecha1, $fecha2) {
    if ((strtotime($fecha1)) < (strtotime($fecha2))) {
        return $fecha1;
    } else {
        return $fecha2;
    }
}
