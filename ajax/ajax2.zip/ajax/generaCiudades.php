<?php

ini_set('error_reporting', E_ALL ^ E_NOTICE);
define(RUTA, __DIR__ . DIRECTORY_SEPARATOR);

require_once RUTA . 'generaCiudades.class.php';

$inicio = microtime(true);
$gc = new generaCiudades();
$gc->destino = 'pruebaGenerarAtributos.xml';
$gc->conAtributos();
unset($gc);
echo "GenerarAtributos tarea realizada en... " . number_format(microtime(true) - $inicio, 4) . " s" . PHP_EOL;

$inicio = microtime(true);
$gc = new generaCiudades();
$gc->destino = 'pruebaJSONstring.xml';
$gc->JSONstring();
unset($gc);
echo "Generar con string tarea realizada en... " . number_format(microtime(true) - $inicio, 4) . " s" . PHP_EOL;

$inicio = microtime(true);
$gc = new generaCiudades();
$gc->destino = 'pruebaJSONnodos.xml';
$gc->JSONnodos();
unset($gc);
echo "Generar con string con nodos tarea realizada en... " . number_format(microtime(true) - $inicio, 4) . " s" . PHP_EOL;
