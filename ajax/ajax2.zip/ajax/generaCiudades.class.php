<?php

ini_set('error_reporting', E_ALL ^ E_NOTICE);
define(RUTA, __DIR__ . DIRECTORY_SEPARATOR);

class generaCiudades {

    public $destino;
    private $dir;
    private $dom, $lugares;

    function __construct() {
        $this->dir = new DirectoryIterator(RUTA . "datas");
        $this->dom = new DOMDocument('1.0', 'utf-8');
    }

    function __destruct() {
        $this->dom->save(RUTA . '../xml/' . $this->destino);
    }

    public function conAtributos() {
        $this->lugares = $this->dom->createElement('LUGARES');
        foreach ($this->dir as $fileInfo) {
            if ($fileInfo->isDot())
                continue;
            $aCiudades = json_decode(file_get_contents(RUTA . "datas/" . $fileInfo->getFilename()), true);
            if (json_last_error() == JSON_ERROR_NONE) {
                foreach ($aCiudades as $valor) {
                    $lugar = $this->dom->createElement('LUGAR');
                    $lugar->setAttribute("id", $valor['id']);
                    $lugar->setAttribute("siglas", $valor['shortName']);
                    $lugar->setAttribute("nombre", $valor['longName']);
                    $lugar->setAttribute("cp", $valor['cp']);
                    $this->lugares->appendChild($lugar);
                }
            }
        }
    }

    public function JSONstring() {
        $str = '<LUGARES>';
        foreach ($this->dir as $fileInfo) {
            if ($fileInfo->isDot())
                continue;
            $aCiudades = json_decode(file_get_contents(RUTA . "datas/" . $fileInfo->getFilename()), true);
            if (json_last_error() == JSON_ERROR_NONE) {
                foreach ($aCiudades as $valor) {
                    $str .= '<LUGAR id="' . $valor['id'] . '" cp="' . $valor['cp'] . '" siglas="' . $valor['shortName'] . '" nombre="' . $valor['longName'] . '">';
                    $str .= '</LUGAR>';
                }
            }
        }
        $str .= '</LUGARES>';
        $this->dom->loadXML($str);
    }

    public function JSONnodos() {
        $this->lugares = $this->dom->createElement('LUGARES');
        $this->dom->appendChild($this->lugares);
        foreach ($this->dir as $fileInfo) {
            if ($fileInfo->isDot())
                continue;
            $aCiudades = json_decode(file_get_contents(RUTA . "datas/" . $fileInfo->getFilename()), true);
            if (json_last_error() == JSON_ERROR_NONE) {
                foreach ($aCiudades as $valor) {
                    $lugar = $this->dom->createElement('LUGAR');
                    $this->lugares->appendChild($lugar);
                    foreach($valor as $k => $v) {
                        $lugar->appendChild($this->dom->createElement($k,$v));
                    }
                }
            }
        }
    }

}
