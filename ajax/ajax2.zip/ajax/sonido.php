<?php
header('Access-Control-Allow-Origin: *'); 
$palabra = $_GET['palabra'];
if (empty($palabra)) {
    echo json_encode(array("status" => "ko", "mensaje" => "palabra vacía"));
} else {
    echo json_encode(array("status" => "ok", "s" => soundex($palabra), "m" => metaphone($palabra)));
}